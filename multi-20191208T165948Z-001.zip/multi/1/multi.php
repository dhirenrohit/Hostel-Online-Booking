

<?php
	$host='localhost';
	$user='root';
	$password='';
	$db='multi';


$con = mysqli_connect($host,$user,$password,$db);
 //Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }



	$Hostelname=$_POST['location'];
	$Username=$_POST['username'];
	$Email=$_POST['email'];
	$Phone=$_POST['phone'];
	$City=$_POST['City'];
	if(isset($_POST['AC'])){
		$ACRequirements=1;
	}else{
		$ACRequirements=0;
	}
	
	$ARRIVAL=$_POST['arrival'];
	$DEPARTURE=$_POST['departure'];
	
	
	$sql="INSERT INTO `registration` ( `Hostelname`, `Username`, `Email`, `Phone`, `ACRequirements`, `ARRIVAL`, `DEPARTURE`) VALUES ( '$Hostelname', '$Username', '$Email', '$Phone', '$ACRequirements', '$ARRIVAL', '$DEPARTURE')";
	if ($con->query($sql) == TRUE) {
		echo "connect successfully";
	}
	else{
		echo "connection failed";
	} 


?>

	