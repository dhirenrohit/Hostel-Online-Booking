<?php


/*if($_SESSION["admin"]==true)
{
	echo "Welcome Admin...!";
	header('logout.php');
}
else{
		echo "Welcome"." ".$_SESSION["user"];
		header('location:lhpage.html');
}*/
?>

<a href="multi.php" target="http://localhost/multi/multi.php">Logout</a>


<?php

if(isset($_POST["submit"]))
{
	$user=$_POST["user"];
	$email=$_POST["email"];
	$phone=$_POST["phone"];
	$city=$_POST["city"];
	$ac=$_POST["ac"];
	$dates=$_POST["dates"];
}
	mysql_fetch_field("insert into post(user,email,phone,city,ac,dates)value('$user','$email','$phone','$city','$ac','$dates')");
    mysql_tablename(result, i)

?>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" >
<script type="text/javascript">
function exportToExcel(tableID, filename = ''){
    var downloadurl;
    var dataFileType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTMLData = tableSelect.outerHTML.replace(/ /g, '%20');
    
    // Specify file name
    filename = filename?filename+'.xls':'export_excel_data.xls';
    
    // Create download link element
    downloadurl = document.createElement("a");
    
    document.body.appendChild(downloadurl);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTMLData], {
            type: dataFileType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadurl.href = 'data:' + dataFileType + ', ' + tableHTMLData;
    
        // Setting the file name
        downloadurl.download = filename;
        
        //triggering the function
        downloadurl.click();
    }
}
 
</script>


		</form>
</head>
</html>