<?php
$host='localhost';
$user='root';
$pass='';
$db='multi';

$con=mysqli_connect($host,$user,$pass,$db);
if($con)
each'connected successfully to login database';
$sql="insert into logindata (username,password,email) values('jhon','12345','anymail@gmail.com')";
$query=mysqi_query($con,$sql);
if($query)
echo 'data inserted successfully';
?>