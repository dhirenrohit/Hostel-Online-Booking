
<?php
session_start();
session_destroy();
$servername="localhost";
$username="root";
$password="";
$dbname="multi";
$conn = mysqli_connect($servername, $username, $password, $dbname);


if(isset($_POST['Login'])){
	$user = $_POST['user'];
	$password = $_POST['pass'];
	$usertype = $_POST['usertype'];
	$query = "SELECT * FROM `multi` WHERE username='".$user."'and password ='".$password."' and usertype = '".$usertype."'";
	$result = mysqli_query($conn,$query);
	if($result){
				while($row=mysqli_fetch_array($result))
	   			{
				 	echo '<script type="text/javascript">alert("You Are Successfully logged in as ' .$row['usertype'].'")			</script>';
						
		     	}
						if($usertype=="admin")
							 {
								?>		
								<script type="text/javascript">
								window.location.href="table.php"
								</script>
								<?php
							  }    
						else{
								?>
								<script type="text/javascript">
								window.location.href="success.html"
								</script>
								
								<?php
							}
		}else{
			echo '<script type="text/javascript">alert("Login Failed")</script>';
		}	
}
?>
<html>
<head>
	<meta charset="utf-8">
	<title>Login System</title>
	<link rel="stylesheet" type="text/css" href="multi.css">
	<link rel="stylesheet" type="text/css" href="b.css">
	<link rel="stylesheet" type="text/css" href="m.js">
	<?php include 'links.php' ?>
</head>
<body>
		<div id='stars'></div>
<div id='stars2'></div>
<div id='stars3'></div>

	<form method="post">
		<div class="container center-div shadow ">
		<div class="heading text-center mb-5 text-black ">Login Page</div>
		<header>
		<table class="container row d-flex flex-row justify-content-center mb-5">
			<tr>
				<td>
					Select User type: <select name="usertype">
						<option value="admin">Admin</option>
						<option value="user">User</option>
					</select>
				</td>
			</tr>
			<tr>
				<td>Username: <input type="text" name="user" placeholder="Enter your username"></td>
			</tr>
			<tr>
				<td>Password: <input type="password" name="pass" placeholder="Enter your Password" autocomplete="off" ></td>
			</tr>
		
			<tr>
				<td><input type="submit" id="Login" name="Login" value="Login"></td>
			</tr>
		</table>

	</form>
</header>
</body>
</html>