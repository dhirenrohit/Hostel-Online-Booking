
<html>
  <body>
    <link rel="stylesheet" type="text/css" href="register.css">
    <link rel="stylesheet" type="text/css" href="register.js">
    <div class="diamond"></div>
    <div class="form-wrap">
     
      <form action="multi.php" method="POST">
        <div class="location">
           <h2>Hotel Booking Form</h2>
         
          <label for="location">Hostel Name</label><br/>
          <input type="text" name="location" placeholder="Enter Hostel Name"/><br/>
        </div>
          <fieldset>
            <legend>Personal Details : </legend>
            <label for="name">Username:</label><input type="text" name="username" id="name" required autofocus placeholder="Your username" pattern="[a-zA-Z]{3,}"title="Please Enter in more than three letters">
            <laber for="email">Email:</laber><input type="text" name="email" id="email" required placeholder="Your Email"pattern="[a-zA-Z]{3,}@[a-zA-Z]{3,}[.]{1}[a-zA-Z]{2,}"title="Please Enter in a valid email address">
            <laber for="phone">Phone:</laber><input type="tel" name="phone" id="phone" required placeholder="Please enter in your Phone number"pattern="[0-9]{4} [0-9]{3} [0-9]{3}"title="Please Enter in a phone number in this format: #### ### ###">
            <select name ="City" required>
                <option value="">City</option>
                <option value="Vadodara">Vadodara</option> 
                <option value="Ahmedabad">Ahmedabad</option>
                <option value="Surat">Surat</option>
                <option value="Rajkot">Rajkot</option>
                <option value="Anand">Anand</option>
                <option value="Nadiad">Nadiad</option>
              </select>
           
        <div class="guests">
          <label for="AC">AC Requirements</label><br/>
          <button type="select" id="cnt-down" name="AC"></button>
          <button type="select" id="cnt-up" name="Non-AC"></button>
        </div>
        <div class="dates">
          <div class="arrival">
            <label for="arrival">ARRIVAL</label><br/>
            <input name="arrival" type="text" onfocus="(this.type='date')" onblur="(this.type='text')" placeholder="10/03/2016"/>
          </div>
          <div class="departure">
            <label for="arrival">DEPARTURE</label><br/>
            <input name="departure" type="text" onfocus="(this.type='date')" onblur="(this.type='text')" placeholder="05/11/2016"/>
          </div>
        </div>
                        <p>Note: Please make sure your details are correct before submitting form and that all fields marked with * are completed!.</p>
      </form>
      <button class="btn" type="check">BOOK NOW</button>
       </fieldset>
      <div class="linkbox">
        <div class="links">
          <div class="origin">
            <p>Check out Seth Coelen's original design over on dribbble</p><a href="https://dribbble.com/shots/2464177-Daily-UI-067-Hotel-Booking" target="_blank"><i class="fa fa-dribbble"></i></a>
          </div>
          <div class="me">
            <p>Why not take a look at my other pens while you're here</p><a href="https://codepen.io/lewisvrobinson"><i class="fa fa-codepen"></i></a>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>